"""
Shodan exposed-services lookup.

Uses the FREE Shodan API (no paid plan required) via:
  https://api.shodan.io/shodan/host/search?key=<KEY>&query=hostname:<domain>

If no API key is configured the module returns a clear error message
so the UI can show a helpful notice instead of crashing.
"""

import httpx
from typing import List


async def lookup_exposed_services(domain: str, api_key: str) -> List[dict]:
    if not api_key:
        return [
            {
                "error": "SHODAN_API_KEY not configured",
                "hint": "Add your free Shodan API key in the .env file or as an env var.",
            }
        ]

    url = "https://api.shodan.io/shodan/host/search"
    params = {
        "key": api_key,
        "query": f"hostname:{domain}",
        "fields": "ip_str,port,transport,product,version,hostnames,org",
        "facets": "port",
    }

    async with httpx.AsyncClient(timeout=20) as client:
        resp = await client.get(url, params=params)
        if resp.status_code == 401:
            return [{"error": "Invalid Shodan API key"}]
        resp.raise_for_status()
        data = resp.json()

    results: List[dict] = []
    for match in data.get("matches", []):
        results.append(
            {
                "ip": match.get("ip_str"),
                "port": match.get("port"),
                "transport": match.get("transport"),
                "product": match.get("product", ""),
                "version": match.get("version", ""),
                "hostnames": match.get("hostnames", []),
                "org": match.get("org", ""),
            }
        )
    return results
