"""
crt.sh subdomain enumeration.
Queries https://crt.sh/?q=%.domain&output=json and deduplicates results.
"""

import httpx
from typing import List


async def enumerate_subdomains(domain: str) -> List[dict]:
    url = f"https://crt.sh/?q=%.{domain}&output=json"
    async with httpx.AsyncClient(timeout=20) as client:
        resp = await client.get(url, follow_redirects=True)
        resp.raise_for_status()
        data = resp.json()

    seen: set[str] = set()
    results: List[dict] = []
    for entry in data:
        name = entry.get("name_value", "").strip()
        # crt.sh sometimes returns multi-line name_value
        for sub in name.splitlines():
            sub = sub.strip().lstrip("*.")
            if sub and sub not in seen:
                seen.add(sub)
                results.append(
                    {
                        "subdomain": sub,
                        "issuer": entry.get("issuer_ca_id"),
                        "logged_at": entry.get("entry_timestamp"),
                    }
                )

    # Sort alphabetically
    results.sort(key=lambda x: x["subdomain"])
    return results
