"""
Public job post scraper.

Strategy (no auth required):
1. Scrape LinkedIn public job search for the company name.
2. Build a Google dork URL (returned as a clickable link) for the user
   to open manually, because Google blocks headless scraping.

Returns structured results where possible, plus a dork_url the frontend
renders as a "Search on Google" button.
"""

import httpx
from bs4 import BeautifulSoup
from typing import List
import urllib.parse


LINKEDIN_URL = "https://www.linkedin.com/jobs/search/"


def _build_google_dork(company: str, domain: str) -> str:
    q = f'site:linkedin.com/jobs OR site:indeed.com "{company}" OR "{domain}"'
    return "https://www.google.com/search?q=" + urllib.parse.quote(q)


async def fetch_job_posts(company: str, domain: str) -> dict:
    dork_url = _build_google_dork(company, domain)

    jobs: List[dict] = []
    try:
        params = {"keywords": company, "location": "", "f_TPR": "r2592000"}  # last 30 days
        headers = {
            "User-Agent": (
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) "
                "Chrome/124.0.0.0 Safari/537.36"
            )
        }
        async with httpx.AsyncClient(timeout=20, headers=headers, follow_redirects=True) as client:
            resp = await client.get(LINKEDIN_URL, params=params)
            if resp.status_code == 200:
                soup = BeautifulSoup(resp.text, "html.parser")
                for card in soup.select("div.job-search-card")[:20]:
                    title_el = card.select_one("h3.base-search-card__title")
                    company_el = card.select_one("h4.base-search-card__subtitle")
                    location_el = card.select_one("span.job-search-card__location")
                    link_el = card.select_one("a.base-card__full-link")
                    jobs.append(
                        {
                            "title": title_el.get_text(strip=True) if title_el else "",
                            "company": company_el.get_text(strip=True) if company_el else "",
                            "location": location_el.get_text(strip=True) if location_el else "",
                            "url": link_el["href"] if link_el else "",
                        }
                    )
    except Exception as exc:
        jobs = [{"error": f"LinkedIn scrape failed: {exc}"}]

    return {
        "jobs": jobs,
        "dork_url": dork_url,
        "note": (
            "LinkedIn may block automated requests. "
            "Use the Google dork link for a reliable manual search."
        ),
    }
